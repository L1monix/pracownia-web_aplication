const addButton: HTMLButtonElement | null = document.querySelector("#todoAddButton");
const inputTextField: HTMLInputElement | null = document.querySelector("#todoInputField");
const inputTextField_count: HTMLInputElement | null = document.querySelector("#todoInputField_count");
const inputTextField_price: HTMLInputElement | null = document.querySelector("#todoInputField_price");
const todosContainer: HTMLDivElement = document.querySelector("#todoContainer")!;

type Todo = {
    id: number,
    title: string,
    price: string,
    count: string,
    description?: string,
    status?: string,
    isDone?: boolean,
}

const savedTodos = localStorage.getItem("todos");
let arrayOfTodos: Todo[] = savedTodos ? JSON.parse(savedTodos) : [];

buildList();

function saveToLocalStorage() {
    localStorage.setItem("todos", JSON.stringify(arrayOfTodos));
}

if (addButton && inputTextField && inputTextField_count && inputTextField_price && todosContainer) {

    addButton.addEventListener('click', (e) => {
        const nextId = arrayOfTodos.length > 0 ? Math.max(...arrayOfTodos.map(t => t.id)) + 1 : 0;

        arrayOfTodos.push({
            id: nextId, 
            title: inputTextField.value,
            price: inputTextField_price.value,
            count: inputTextField_count.value,
            status: "Nie ma"
        });

        inputTextField.value = '';
        inputTextField_price.value = '';
        inputTextField_count.value = '';
        
        saveToLocalStorage();
        buildList();
    });
}

function buildList() {
    todosContainer.innerHTML = "";
    arrayOfTodos.forEach(element => {
        let container = document.createElement("div");
        container.classList.add("card", "card-body", "mt-1", "shadow");

        let id = document.createElement('p');
        id.classList.add("small");

        let title = document.createElement('h3');
        title.classList.add("h3");

        let price = document.createElement('h4');
        price.classList.add("h4"); 

        let count = document.createElement('h4');
        count.classList.add("h4"); 

        let select = document.createElement("select");
        select.classList.add("w-100");

        let option1 = document.createElement("option");
        option1.value = "Nie ma";
        option1.textContent = "Nie ma";

        let option2 = document.createElement("option");
        option2.value = "Jest";
        option2.textContent = "Jest";

        select.appendChild(option1);
        select.appendChild(option2);
        
        if (!element.status) {
            element.status = "Nie ma";
        }
        select.value = element.status;

        let status = document.createElement('h3');
        status.classList.add("h3");
        status.textContent = "Dostępność produktu: " + element.status; 

        select.addEventListener('change', (event: Event) => {
            const target = event.target as HTMLSelectElement;
            element.status = target.value;
            status.textContent = "Dostępność produktu: " + element.status;
            
            saveToLocalStorage();
        });

        let delButton = document.createElement('button');
        delButton.classList.add("btn", "btn-danger");
        delButton.innerText = "Delete";

        delButton.addEventListener('click', () => {
            deleteTodo(element.id);
        });

        id.textContent = "ID: " + element.id;
        title.textContent = "Tytuł: " + element.title;
        price.textContent = "Cena: " + element.price;
        count.textContent = "Ilość: " + element.count;

        container.appendChild(id);
        container.appendChild(title);
        container.appendChild(price);
        container.appendChild(count);
        container.appendChild(select);
        container.appendChild(status);
        container.appendChild(delButton);

        todosContainer.appendChild(container);
    });
}

function deleteTodo(id: number) {
    arrayOfTodos = arrayOfTodos.filter(todo => todo.id !== id);
    saveToLocalStorage();
    buildList();
}
