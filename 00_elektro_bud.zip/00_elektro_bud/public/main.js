"use strict";
let products = JSON.parse(localStorage.getItem("products") || "[]");
let historyList = JSON.parse(localStorage.getItem("history") || "[]");
const roleSelect = document.getElementById("roleSelect");
const searchField = document.getElementById("searchField");
const userInput = document.getElementById("userInput");
const todoContainer = document.getElementById("todoContainer");
const historyContainer = document.getElementById("historyContainer");
const addForm = document.getElementById("addForm");
const historySection = document.getElementById("historySection");
roleSelect.value = localStorage.getItem("role") || "magazynier";
roleSelect.addEventListener("change", function () {
    localStorage.setItem("role", roleSelect.value);
    buildList();
});
searchField.addEventListener("input", function () {
    buildList();
});
document.getElementById("todoAddButton").addEventListener("click", function () {
    let ean = document.getElementById("f_ean").value;
    let title = document.getElementById("f_title").value;
    let category = document.getElementById("f_category").value;
    let sector = document.getElementById("f_sector").value;
    let rack = document.getElementById("f_rack").value;
    let shelf = document.getElementById("f_shelf").value;
    let count = Number(document.getElementById("f_count").value);
    if (ean == "" || title == "") {
        alert("Podaj EAN i nazwę produktu");
        return;
    }
    let product = {
        id: Date.now(),
        ean: ean,
        title: title,
        category: category,
        sector: sector,
        rack: rack,
        shelf: shelf,
        count: count
    };
    products.push(product);
    localStorage.setItem("products", JSON.stringify(products));
    addHistory(title, "Nowy produkt", count);
    // czyszczenie formularza
    let ids = ["f_ean", "f_title", "f_category", "f_sector", "f_rack", "f_shelf", "f_count"];
    for (let i = 0; i < ids.length; i++) {
        document.getElementById(ids[i]).value = "";
    }
    buildList();
});
function buildList() {
    let query = searchField.value.toLowerCase();
    let manager = roleSelect.value == "kierownik";
    if (manager) {
        addForm.classList.remove("d-none");
        historySection.classList.remove("d-none");
    }
    else {
        addForm.classList.add("d-none");
        historySection.classList.add("d-none");
    }
    let html = "";
    for (let i = 0; i < products.length; i++) {
        let p = products[i];
        if (p.ean.includes(query) || p.title.toLowerCase().includes(query)) {
            html += `
            <div class="card card-body mt-1 shadow">
                <h3 class="h3">${p.title}</h3>
                <p class="small mb-1">EAN: ${p.ean} | Kategoria: ${p.category}</p>
                <h4 class="h5">Lokalizacja: sektor ${p.sector}, regał ${p.rack}, półka ${p.shelf}</h4>
                <h4 class="h4">Ilość: ${p.count}</h4>
                <div>
                    <button class="btn btn-success" onclick="changeStock(${p.id}, 'Przyjęcie')">Przyjmij</button>
                    <button class="btn btn-warning" onclick="changeStock(${p.id}, 'Wydanie')">Wydaj</button>`;
            if (manager) {
                html += `<button class="btn btn-danger" onclick="deleteProduct(${p.id})">Usuń</button>`;
            }
            html += `</div></div>`;
        }
    }
    todoContainer.innerHTML = html;
}
function changeStock(id, type) {
    if (userInput.value == "") {
        alert("Wpisz imię i nazwisko pracownika");
        return;
    }
    let amount = Number(prompt(type + " - podaj ilość:"));
    if (!Number.isInteger(amount) || amount <= 0) {
        return;
    }
    for (let i = 0; i < products.length; i++) {
        if (products[i].id == id) {
            if (type == "Wydanie") {
                if (amount > products[i].count) {
                    alert("Za mało towaru! Na magazynie: " + products[i].count);
                    return;
                }
                products[i].count = products[i].count - amount;
            }
            else {
                products[i].count = products[i].count + amount;
            }
            addHistory(products[i].title, type, amount);
        }
    }
    localStorage.setItem("products", JSON.stringify(products));
    buildList();
}
function deleteProduct(id) {
    let newProducts = [];
    for (let i = 0; i < products.length; i++) {
        if (products[i].id == id) {
            addHistory(products[i].title, "Usunięcie", products[i].count);
        }
        else {
            newProducts.push(products[i]);
        }
    }
    products = newProducts;
    localStorage.setItem("products", JSON.stringify(products));
    buildList();
}
function addHistory(product, type, amount) {
    let user = userInput.value;
    if (user == "") {
        user = "(brak)";
    }
    historyList.push({
        date: new Date().toLocaleString("pl-PL"),
        user: user,
        product: product,
        type: type,
        amount: amount
    });
    localStorage.setItem("history", JSON.stringify(historyList));
    buildHistory();
}
function buildHistory() {
    let html = "";
    for (let i = historyList.length - 1; i >= 0; i--) {
        let o = historyList[i];
        html += `<div class="card card-body mt-1 small">
            ${o.date} | ${o.user} | ${o.type} | ${o.product} | ilość: ${o.amount}</div>`;
    }
    historyContainer.innerHTML = html;
}
buildList();
buildHistory();
